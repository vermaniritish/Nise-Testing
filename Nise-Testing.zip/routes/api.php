<?php

use App\Http\Controllers\API\AddressesController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\CouponsController;
use App\Http\Controllers\API\OrdersController;
use App\Http\Controllers\API\ProductCategoriesController;
use App\Http\Controllers\API\ProductsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware(['guest:api'])->group(function () {
});
