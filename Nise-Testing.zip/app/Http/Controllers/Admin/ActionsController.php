<?php

/**
 * Actions Class
 *
 * @package    ActionsController
 
 
 * @version    Release: 1.0.0
 * @since      Class available since Release 1.0.0
 */


namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Validator;
use App\Models\Admin\Settings;
use App\Models\Admin\Blogs;
use App\Models\Admin\Permissions;
use App\Models\Admin\AdminAuth;
use App\Models\Admin\District;
use App\Libraries\General;
use App\Libraries\FileSystem;
use App\Models\Admin\Actions;
use App\Models\PartnerAdmin\Center;
use App\Models\PartnerAdmin\Batche;
use App\Models\Admin\PollingStation;
use App\Models\Admin\TestServiceCategory;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;

class ActionsController extends AppController
{
	function __construct()
	{
		parent::__construct();
	}

	/**
	* To Upload File
	* @param Request $request
	*/
    function uploadFile(Request $request)
    {
    	$data = $request->toArray();
    	$validator = Validator::make(
            $request->toArray(),
            [
                'path' => 'required',
                'file_type' => 'required',
                'file' => 'required',
            ]
        );

    	if(!$validator->fails())
	    {
	    	if($request->file('file')->isValid())
	    	{
	    		$file = null;
	    		if($data['file_type'] == 'image')
	    		{
		    		$file = FileSystem::uploadImage(
	    				$request->file('file'),
	    				$data['path']
	    			);

	    			if($file)
	    			{
	    				$originalName = FileSystem::getFileNameFromPath($file);

	    				if(isset($data['resize_large']) && $data['resize_large'])
	    				{
	    					FileSystem::resizeImage($file, $originalName, $data['resize_large']);
	    				}
	    				
	    				if(isset($data['resize_small']) && $data['resize_small'])
	    				{
	    					FileSystem::resizeImage($file, 'S-' . $originalName, $data['resize_small']);
	    				}
					}
		    	}
		    	else
		    	{
		    		$file = FileSystem::uploadFile(
	    				$request->file('file'),
	    				$data['path']
	    			);
		    	}

    			if($file)
    			{
    				$names = explode('/', $file);
					return Response()->json([
				    	'status' => 'success',
				    	'message' => 'File uploaded successfully.',
				    	'url' => url($file),
				    	'name' => end($names),
				    	'path' => $file
				    ]);
    				
    			}
    			else
    			{
    				return Response()->json([
				    	'status' => 'error',
				    	'message' => 'File could not be upload.'
				    ]);		
    			}
	    	}
	    	else
	    	{
	    		return Response()->json([
		    	'status' => 'error',
		    	'message' => 'File could not be uploaded.'
		    ]);	
	    	}
	   	}
	    else
	    {
	    	return Response()->json([
		    	'status' => 'error',
		    	'message' => 'File could not be uploaded due to missing parameters.'
		    ]);	
	    }
    }

    /**
	* To Remove File
	* @param Request $request
	*/
    function removeFile(Request $request)
    {
    	$data = $request->toArray();

    	$validator = Validator::make(
            $request->toArray(),
            [
                'file' => 'required',
            ]
        );

    	if(!$validator->fails())
	    {
	    	if(isset($data['relation']) && $data['relation'])
	    	{
	    		$relation = explode('.', $data['relation']);
	    		if(count($relation) > 1 && $relation[0] == 'settings')
	    		{
	    			// In case of settings table
	    			if(Settings::put($relation[1], ""))
					{
						FileSystem::deleteFile($data['file']);
						return Response()->json([
					    	'status' => 'success',
					    	'message' => 'File removed successfully.'
					    ]);
					}
					else
					{
						return Response()->json([
					    	'status' => 'error',
					    	'message' => 'File could not be removed.'
					    ]);  		
					}
	    		}
	    		else if(count($relation) > 1 && isset($data['id']) && $data['id'])
	    		{
	    			// In case of other tables
	    			$record = DB::table($relation[0])
			            ->select([
			            	$relation[1]
			            ])
			            ->where('id', $data['id'])
			            ->limit(1)
			            ->first();

			        if($record && $record->{$relation[1]})
			        {
			        	$file = $record->{$relation[1]};
			        	$multiple = json_decode($file, true);
						$allFiles = $multiple && is_array($multiple) ? $multiple : ($file ? [$file] : null);
						
						$index = array_search($data['file'], $allFiles);
						if($index !== false && isset($allFiles[$index]) && $allFiles[$index])
						{
							unset($allFiles[$index]);
							$allFiles = array_values($allFiles);
							$allFiles = !empty($allFiles) ? json_encode($allFiles) : "";
							$updated  = DB::table($relation[0])
								->where('id', $data['id'])
								->update([
									"{$relation[1]}" => $allFiles
								]);
							if($updated)
							{
								FileSystem::deleteFile($data['file']);
								return Response()->json([
							    	'status' => 'success',
							    	'message' => 'File removed successfully.'
							    ]);
							}
							else
							{
								return Response()->json([
							    	'status' => 'error',
							    	'message' => 'File could not be removed.'
							    ]);  		
							}
						}
						else
						{
							return Response()->json([
						    	'status' => 'error',
						    	'message' => 'File could not be removed.'
						    ]);  
						}
			        }
			    }
			    else
			    {
			 		return Response()->json([
				    	'status' => 'error',
				    	'message' => 'Relation is missing or invalid.'
				    ]);   	
			    }
	    	}
	    	elseif(FileSystem::deleteFile($data['file']))
    		{
    			return Response()->json([
			    	'status' => 'success',
			    	'message' => 'File removed successfully.'
			    ]);
    		}
    		else
    		{
	    		return Response()->json([
			    	'status' => 'error',
			    	'message' => 'File could not be removed.'
			    ]);
	    	}
	    }
	    else
	    {
	    	return Response()->json([
		    	'status' => 'error',
		    	'message' => 'File parameter is missing.'
		    ]);
	    }
    }

    /**
	* To Upload File
	* @param Request $request
	* @param $table
	* @param $field
	* @param $id
	*/
    function switchUpdate(Request $request, $table, $field, $id)
    {
    	$data = $request->toArray();

    	$validator = Validator::make(
            $request->toArray(),
            [
                'flag' => 'required'
            ]
        );

    	if(!$validator->fails())
	    {
	    	$updated  = DB::table($table)
					->where('id', $id)
					->update([
						"{$field}" => $request->get('flag')
					]);
	    	if($updated)
	    	{
	    		return Response()->json([
			    	'status' => 'success',
			    	'message' => 'Record updated successfully.'
			    ]);	
	    	}
	    	else
	    	{
	    		return Response()->json([
			    	'status' => 'error',
			    	'message' => 'Record could not be update.'
			    ]);		
	    	}
	    	
	    }
	    else
	    {
	    	return Response()->json([
		    	'status' => 'error',
		    	'message' => 'Record could not be update.'
		    ]);
	    }
    }

	function stations(Request $request, $id)
	{
		$html = '';
		if($id)
		{
            $stations = PollingStation::where('constituency_id', $id)->orderBy('title', 'asc')->get();
			foreach($stations as $s)
			{
				$html .= '<option value="'.$s->id.'">' . $s->title . ' | ' . $s->poll_station_id .'</option>';
			}
		}

		return Response()->json([
			'status' => true,
			'html' => $html
		]);
	}

	function getDistrictsByStateId(Request $request, $state_id)
	{
		$select = [
			'district.id',
			'district.name',
			'district.status'
		];
		$where['district.status = ?'] = [1];
		$where['district.state_id = ?'] = [$state_id];

		$order = 'district.name asc';
		$district = District::getAll($select, $where, $order);

		$html = view(
			"admin/actions/getDistrict",
			[
				'district' => $district
			]
		)->render();


		return Response()->json([
			'status' => 'success',
			'html' => $html
		]);
	}

	function getCenterByInstituteId(Request $request, $institute_id)
	{
		$select = [
			'centers.id',
			'centers.title',
			'centers.status'
		];
		$where['centers.status = ?'] = [1];
		$where['centers.institute_id = ?'] = [$institute_id];

		$order = 'centers.title asc';
		$centers = Center::getAll($select, $where, $order);

		$html = view(
			"admin/actions/getCenter",
			[
				'centers' => $centers
			]
		)->render();


		return Response()->json([
			'status' => 'success',
			'html' => $html
		]);
	}

	function getBatchByCenterId(Request $request, $center_id)
	{
		$select = [
			'batches.id',
			'batches.batch_title',
			'batches.status'
		];
		// $where['batches.status = ?'] = [1];
		$where['batches.center_id = ?'] = [$center_id];

		$order = 'batches.batch_title asc';
		$batches = Batche::getAll($select, $where, $order);

		$html = view(
			"admin/actions/getBatch",
			[
				'batches' => $batches
			]
		)->render();


		return Response()->json([
			'status' => 'success',
			'html' => $html
		]);
	}

	function getServiceCatByServiceId(Request $request, $test_service_id)
	{
		$select = [
			'testing_service_categories.id',
			'testing_service_categories.test_category_title'
		];
		// $where['batches.status = ?'] = [1];
		$where['testing_service_categories.test_service_id = ?'] = [$test_service_id];

		$order = 'testing_service_categories.test_category_title asc';
		$testServiceCategories = TestServiceCategory::getAll($select, $where, $order);

		$html = view(
			"admin/actions/getServiceCategory",
			[
				'testServiceCategories' => $testServiceCategories
			]
		)->render();


		return Response()->json([
			'status' => 'success',
			'html' => $html
		]);
	}
}
